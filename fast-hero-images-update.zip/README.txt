FAST HERO IMAGE UPDATE

This package contains:
- index.html: same page with WebP hero image paths, image preloads, and a full-image 16:9 mobile layout.
- sw.js: cache version v11 and precaches all three small WebP banners.
- hero-banner-1.webp, hero-banner-2.webp, hero-banner-3.webp

Upload these five files to the repository root, replacing index.html and sw.js. Keep app.js, styles.css, and the rest of your app files in the repository root. Commit the changes. Keep your original PNG files if you want; these updated paths use the WebP copies.
